from langchain_community.document_loaders.image_captions import ImageCaptionLoader

__all__ = ["ImageCaptionLoader"]
