from langchain_community.document_loaders.blackboard import BlackboardLoader

__all__ = ["BlackboardLoader"]
