from langchain_community.document_loaders.parsers.registry import (
    get_parser,
)

__all__ = ["get_parser"]
