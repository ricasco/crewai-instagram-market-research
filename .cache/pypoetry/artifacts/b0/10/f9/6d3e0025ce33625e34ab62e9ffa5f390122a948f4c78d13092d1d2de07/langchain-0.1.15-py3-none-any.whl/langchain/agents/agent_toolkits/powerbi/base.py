from langchain_community.agent_toolkits.powerbi.base import create_pbi_agent

__all__ = ["create_pbi_agent"]
