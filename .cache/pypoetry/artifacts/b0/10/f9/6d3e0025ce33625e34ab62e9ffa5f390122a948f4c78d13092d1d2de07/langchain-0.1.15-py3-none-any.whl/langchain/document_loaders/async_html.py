from langchain_community.document_loaders.async_html import (
    AsyncHtmlLoader,
)

__all__ = ["AsyncHtmlLoader"]
