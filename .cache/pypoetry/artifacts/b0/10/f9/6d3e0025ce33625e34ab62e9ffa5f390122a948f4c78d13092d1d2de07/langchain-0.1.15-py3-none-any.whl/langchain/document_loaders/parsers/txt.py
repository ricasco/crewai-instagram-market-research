from langchain_community.document_loaders.parsers.txt import TextParser

__all__ = ["TextParser"]
