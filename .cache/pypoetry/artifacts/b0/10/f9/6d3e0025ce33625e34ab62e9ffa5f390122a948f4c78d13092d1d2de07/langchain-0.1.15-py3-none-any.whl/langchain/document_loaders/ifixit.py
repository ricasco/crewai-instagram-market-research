from langchain_community.document_loaders.ifixit import IFixitLoader

__all__ = ["IFixitLoader"]
