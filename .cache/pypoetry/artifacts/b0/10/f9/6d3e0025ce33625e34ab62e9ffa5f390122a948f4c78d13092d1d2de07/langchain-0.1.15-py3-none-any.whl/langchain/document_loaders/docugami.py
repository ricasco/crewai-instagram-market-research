from langchain_community.document_loaders.docugami import (
    DocugamiLoader,
)

__all__ = [
    "DocugamiLoader",
]
