from langchain_community.document_loaders.max_compute import MaxComputeLoader

__all__ = ["MaxComputeLoader"]
