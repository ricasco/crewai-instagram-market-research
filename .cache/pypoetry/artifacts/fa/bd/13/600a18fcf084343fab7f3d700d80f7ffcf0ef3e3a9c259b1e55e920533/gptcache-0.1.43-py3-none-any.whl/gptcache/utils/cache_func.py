def cache_all(*_, **__):
    return True
