"""gptcache version"""
__version__ = "0.1.43"

from gptcache.config import Config
from gptcache.core import Cache
from gptcache.core import cache
