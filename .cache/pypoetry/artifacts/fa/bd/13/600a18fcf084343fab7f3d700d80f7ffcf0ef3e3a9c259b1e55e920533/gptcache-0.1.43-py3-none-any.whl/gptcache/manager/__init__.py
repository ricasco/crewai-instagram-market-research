from gptcache.manager.scalar_data import CacheBase
from gptcache.manager.vector_data import VectorBase
from gptcache.manager.object_data import ObjectBase
from gptcache.manager.factory import get_data_manager, manager_factory
