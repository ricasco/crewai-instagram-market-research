def to_embeddings(data, **_):
    """Nothing to do, return the origin data"""
    return data
